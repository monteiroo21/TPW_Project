# TPW

## install dependencies

```bash
pip install -r requirements.txt
```

windows
.\venv\Scripts\activate

npm init -y

npm install -D tailwindcss postcss autoprefixer

npx tailwindcss init -p

npx tailwindcss -i ./app/static/content/tailwind.css -o ./app/static/content/style.css --watch
